﻿#ifndef _CELL_SELECT_HPP_
#define _CELL_SELECT_HPP_

#include"CELL.hpp"
#include"CELLConfig.hpp"

#ifdef _WIN32
	//#define FD_SETSIZE      65535
	typedef fd_set cell_fd_set;
	#define CELL_FD_ZERO(set) FD_ZERO(&set)
	#define CELL_FD_SET(fd,set) FD_SET(fd,set)
#else

#define CELL_MAX_FD 10240//FD_SETSIZE

#define CELL_FD_SET(fd,set) \
	if(fd < CELL_MAX_FD)\
	{\
		FD_SET(fd, set);\
	}\
	else\
	{\
		CELLLog::Error("CELL_FD_SET fd<%d> CELL_MAX_FD<%d>  \n",fd,CELL_MAX_FD);\
	}

	#if __linux__
		struct cell_fd_set {
			unsigned long fds_bits[CELL_MAX_FD / (8 * sizeof(long))];
		};
		#define CELL_FD_ZERO(set) memset(&set,0,sizeof(set))
		//typedef fd_set cell_fd_set;
		//#define CELL_FD_ZERO(set) FD_ZERO(&set)
	#else
		typedef fd_set cell_fd_set;
		#define CELL_FD_ZERO(set) FD_ZERO(&set)
	#endif

#endif

//信号量
class CELLFDSet
{
public:
	CELLFDSet()
	{
		int nSocketNum = 10240;
#ifdef _WIN32
		_nfdSzie = sizeof(u_int) + sizeof(SOCKET)*nSocketNum;
#else
		_nfdSzie = nSocketNum / (8 * sizeof(long));
#endif
		_p_fd_set = (fd_set*)new char[_nfdSzie];
		memset(_p_fd_set, 0, _nfdSzie);
	}

	~CELLFDSet()
	{
		if (_p_fd_set)
		{
			delete[] _p_fd_set;
			_p_fd_set = nullptr;
		}
	}

	inline void add(SOCKET sock)
	{
		if(_p_fd_set)
		FD_SET(sock, _p_fd_set);
	}

	inline void del(SOCKET sock)
	{
		FD_CLR(sock, _p_fd_set);
	}

	inline void zero()
	{
		memset(_p_fd_set, 0, _nfdSzie);
	}

	inline bool has(SOCKET sock)
	{
		return FD_ISSET(sock, _p_fd_set);
	}

	inline fd_set* fdset()
	{
		return _p_fd_set;
	}

	inline void copy(CELLFDSet& set)
	{
		memcpy(_p_fd_set, set._p_fd_set, set._nfdSzie);
	}
private:
	//socket fd_set
	fd_set* _p_fd_set = nullptr;
	size_t _nfdSzie = 0;
};



#endif // !_CELL_SELECT_HPP_

//虚假唤醒