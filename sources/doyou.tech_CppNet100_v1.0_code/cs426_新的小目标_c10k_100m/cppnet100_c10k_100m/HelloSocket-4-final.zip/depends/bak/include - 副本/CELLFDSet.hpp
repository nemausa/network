﻿#ifndef _CELL_SELECT_HPP_
#define _CELL_SELECT_HPP_

#include"CELL.hpp"
#include"CELLConfig.hpp"

//信号量
class CELLFDSet
{
public:
	CELLFDSet()
	{
		int nSocketNum = 10240;
#ifdef _WIN32
		_nfdSzie = sizeof(u_int) + sizeof(SOCKET)*nSocketNum;
#else
		_nfdSzie = nSocketNum / (8 * sizeof(long));
#endif
		_p_fd_set = (fd_set*)new char[_nfdSzie];
		memset(_p_fd_set, 0, _nfdSzie);
	}

	~CELLFDSet()
	{
		if (_p_fd_set)
		{
			delete[] _p_fd_set;
			_p_fd_set = nullptr;
		}
	}

	inline void add(SOCKET sock)
	{
		if(_p_fd_set)
		FD_SET(sock, _p_fd_set);
	}

	inline void del(SOCKET sock)
	{
		FD_CLR(sock, _p_fd_set);
	}

	inline void zero()
	{
		memset(_p_fd_set, 0, _nfdSzie);
	}

	inline bool has(SOCKET sock)
	{
		return FD_ISSET(sock, _p_fd_set);
	}

	inline fd_set* fdset()
	{
		return _p_fd_set;
	}

	inline void copy(CELLFDSet& set)
	{
		memcpy(_p_fd_set, set._p_fd_set, set._nfdSzie);
	}
private:
	//socket fd_set
	fd_set* _p_fd_set = nullptr;
	size_t _nfdSzie = 0;
};



#endif // !_CELL_SELECT_HPP_

//虚假唤醒