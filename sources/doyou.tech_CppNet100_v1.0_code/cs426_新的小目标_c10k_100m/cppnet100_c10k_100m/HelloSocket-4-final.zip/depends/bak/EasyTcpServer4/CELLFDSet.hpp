﻿#ifndef _CELL_FDSET_HPP_
#define _CELL_FDSET_HPP_

#include"CELL.hpp"

class CELLFDSet
{
public:
	CELLFDSet()
	{
		int nSocketNum = 10240;
#ifdef _WIN32
		_nfdSize = sizeof(u_int) + (sizeof(SOCKET)*nSocketNum);
#else
		_nfdSize = nSocketNum / (8 * sizeof(char));
#endif // _WIN32
		_pfdset = (fd_set *)new char[_nfdSize];
		memset(_pfdset, 0, _nfdSize);
	}

	~CELLFDSet()
	{
		if (_pfdset)
		{
			delete[] _pfdset;
			_pfdset = nullptr;
		}
	}

	inline void add(SOCKET s)
	{
		//if(_pfdset)
		FD_SET(s, _pfdset);
	}

	inline void del(SOCKET s)
	{
		FD_CLR(s, _pfdset);
	}

	inline void zero()
	{
#ifdef _WIN32
		FD_ZERO(_pfdset);
#else
		memset(_pfdset, 0, _nfdSize);
#endif // _WIN32
	}

	inline bool has(SOCKET s)
	{
		return FD_ISSET(s, _pfdset);
	}

	inline fd_set* fdset()
	{
		return _pfdset;
	}

	void copy(CELLFDSet& set)
	{
		memcpy(_pfdset, set.fdset(), set._nfdSize);
	}
private:
	fd_set * _pfdset = nullptr;
	size_t _nfdSize = 0;
};


#endif // !_CELL_FDSET_HPP_
