#设置执行环境为当前脚本所在目录
cd `dirname $0`
echo “..当前系统单进程最大文件数..”
#launchctl limit maxfiles
ulimit -n
echo “..重置系统单进程最大文件数..”
ulimit -n 10240
echo “..当前系统单进程最大文件数..”
ulimit -n
echo “..启动服务端..”
#
cmd=strIP="any"
cmd=$cmd' nPort=4567'
cmd=$cmd" nThread=1"
#客户端连接上限
cmd="$cmd nMaxClient=10000"
#客户端发送缓冲区大小（字节）
cmd="$cmd nSendBuffSize=20480"
#客户端接收缓冲区大小（字节）
cmd="$cmd nRecvBuffSize=20480"
#收到消息后将返回应答消息
cmd="$cmd -sendback"
#提示发送缓冲区已写满
#当出现sendfull提示时，表示当次消息被丢弃
cmd="$cmd -sendfull"
#检查接收到的客户端消息ID是否连续
cmd="$cmd -checkMsgID"

gdb ./EasyTcpServer

read -p "..press any key to exit.." var
