#设置执行环境为当前脚本所在目录
cd `dirname $0`
echo “..当前系统单进程最大文件数..”
#launchctl limit maxfiles
ulimit -n
echo “..重置系统单进程最大文件数..”
ulimit -n 10240
echo “..当前系统单进程最大文件数..”
ulimit -n
echo “..启动服务端..”
#
#服务端IP地址
strIP="any"
#服务端端口
nPort=4566
#消息线程数量 CellServer
nThread=1
#限制客户端数量 未启用
nClient=3
#启动服务端
./server.out $strIP $nPort $nThread $nClient
#
read -p "..按任意键退出.." var
#read -p "Press any key to exit." var
