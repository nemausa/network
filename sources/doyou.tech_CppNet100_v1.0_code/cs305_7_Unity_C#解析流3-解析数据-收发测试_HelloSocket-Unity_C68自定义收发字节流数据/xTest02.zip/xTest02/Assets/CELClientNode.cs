﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Runtime.InteropServices;
using AOT;
using System;

public class CELClientNode : CELLTCPCLient
{

    //[DllImport("CppNet100")]
    //private static extern int Add(int a, int b);

    //public delegate void CallBack1(string s);

    //[DllImport("CppNet100")]
    //private static extern void TestCall1(string s, CallBack1 cb);

    //[MonoPInvokeCallback(typeof(CallBack1))]
    //public static  void CallBackFun1(string s)
    //{
    //    Debug.Log(s);
    //}
    public string IP = "192.168.1.102";
    public short PORT = 4567;
    // Use this for initialization
    void Start () {
        //Debug.Log(Add(4,5));
        //TestCall1("Hei Hei", CallBackFun1);

        this.Create();
        this.Connect(IP, PORT);
    }
	
	// Update is called once per frame
	void Update () {
        this.OnRun();

        CELLSendStream s = new CELLSendStream(256);
        s.setNetCmd(NetCMD.LOGOUT);
        s.WriteInt8(1);
        s.WriteInt16(2);
        s.WriteInt32(3);
        s.WriteFloat(4.5f);
        s.WriteDouble(6.7);
        s.WriteString("哈哈哈client");
        s.WriteString("ahah嘿嘿嘿");
        int[] b = { 1, 2, 3, 4, 5 };
        s.WriteInt32s(b);
        s.finsh();
        this.SendData(s.Array);
    }

    void OnDestroy()
    {
        this.Close();
    }

    public override void OnNetMsgBytes(byte[] data)
    {
        CELLRecvStream r = new CELLRecvStream(data);
        //消息长度
        Debug.Log(r.ReadUInt16());
        //消息类型
        Debug.Log(r.ReadNetCmd());
        //
        Debug.Log(r.ReadInt8());
        Debug.Log(r.ReadInt16());
        Debug.Log(r.ReadInt32());
        Debug.Log(r.ReadFloat());
        Debug.Log(r.ReadDouble());
        Debug.Log(r.ReadString());
        Debug.Log(r.ReadString());
        Int32[] arr = r.ReadInt32s();
        for(int n = 0; n < arr.Length; n++)
        {
            Debug.Log(arr[n]);
        }
    }
}
